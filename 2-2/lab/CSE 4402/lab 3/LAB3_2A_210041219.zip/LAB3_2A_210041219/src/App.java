public class App {
    public static void main(String[] args) throws Exception {
        Cube c1 = new Cube(4);
        c1.calculateVolume();

        Sphere s1 = new Sphere(5.6);
        s1.calculateSurfaceArea();

        EnigmaMachine em = new EnigmaMachine();
        //em.encode("test.txt", 7);
        em.decode("test.txt", 7);
    }
}
