public abstract class Shape3D{
    abstract void calculateVolume();
    abstract void calculateSurfaceArea();
}