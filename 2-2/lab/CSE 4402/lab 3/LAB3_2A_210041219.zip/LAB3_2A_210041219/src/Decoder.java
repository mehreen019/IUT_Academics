public interface Decoder{
    abstract void decode(String fileName, int key);
}