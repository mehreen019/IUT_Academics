public interface Encoder{
    abstract void encode(String fileName, int key);
}