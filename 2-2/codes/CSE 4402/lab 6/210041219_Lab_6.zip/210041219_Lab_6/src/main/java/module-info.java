module com.example.lab_6_210041219 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.lab_6_210041219 to javafx.fxml;
    exports com.example.lab_6_210041219;
}