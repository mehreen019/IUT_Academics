#include "Vec3.h"

#include <cmath>

#include "Util.h"

Vec3::Vec3(double x, double y, double z) : m_Values{x, y, z} {}

Vec3::Vec3(double v) : Vec3{ v, v, v } {}

Vec3::Vec3() : Vec3{0.0, 0.0, 0.0} {}

double& Vec3::x() { return m_Values[0]; }
double& Vec3::y() { return m_Values[1]; }
double& Vec3::z() { return m_Values[2]; }

double Vec3::x() const { return m_Values[0]; }
double Vec3::y() const { return m_Values[1]; }
double Vec3::z() const { return m_Values[2]; }

bool Vec3::operator==(const Vec3& other) const
{
    int cnt=0;
    
    if(other.x() == x() ) cnt++;
    if(other.y() == y()) cnt++;
    if(other.z() == z()) cnt++;

    if(cnt==3) return true;
    else return false;
}

bool Vec3::operator!=(const Vec3& other) const
{
   int cnt=0;
    
    if(other.x() == x() ) cnt++;
    if(other.y() == y()) cnt++;
    if(other.z() == z()) cnt++;

    if(cnt==3) return false;
    else return true;
}

Vec3 Vec3::operator-() const
{ 
    return Vec3{-1*(x()), -1*(y()), -1*(z())};
}
double Vec3::operator[](size_t index) const
{
    if(index==0) return x();
    else if(index==1) return y();
    else if(index==2) return z();
}
double& Vec3::operator[](size_t index)
{
  
    return m_Values[index];
}

Vec3& Vec3::operator+=(const Vec3& other)
{

    m_Values[0]+=other.x();
    m_Values[1]+=other.y();
    m_Values[2]+=other.z();

    return *this;
}

Vec3& Vec3::operator*=(const double t)
{
    m_Values[0]*=t;
    m_Values[1]*=t;
    m_Values[2]*=t;

    return *this;
}

Vec3& Vec3::operator/=(const double t)
{
    m_Values[0]/=t;
    m_Values[1]/=t;
    m_Values[2]/=t;

    return *this;
}

Vec3 Vec3::operator+(const Vec3& other) const 
{
    // ToDo: Element wise add the other vector to this vector and return a new vector containing the value
    return Vec3{ x()+ other.x(), y()+other.y(), z()+other.z() };
}

Vec3 Vec3::operator+(double t) const 
{
    // ToDo: Add double t with each of the elements of this vector and return a new vector containing the value
    return Vec3{ x()+t, y()+t, z()+t };
}

Vec3 Vec3::operator-(const Vec3& other) const
{
    // ToDo: Element wise subtract the other vector from this vector and return a new vector containing the value
    return Vec3{ x()-other.x(), y()-other.y(), z()-other.z() };
}

Vec3 Vec3::operator-(double t) const
{
    // ToDo: Subtract double t with each of the elements of this vector and return a new vector containing the value
    return Vec3{ x()-t, y()-t, z()-t };
}

Vec3 Vec3::operator*(const Vec3& other) const
{
    // ToDo: Element wise multiply the other vector from this vector and return a new vector containing the value
    return Vec3{ x()*other.x(), y()*other.y(), z()*other.z() };
}

Vec3 Vec3::operator*(double t) const
{
    // ToDo: Multiply double t with each of the elements of this vector and return a new vector containing the value
    return Vec3{  x()*t, y()*t, z()*t };
}

Vec3 Vec3::operator/(const Vec3& other) const
{
    // ToDo: Element wise divide this vector by the other vector and return a new vector containing the value
    return Vec3{ x()/other.x(), y()/other.y(), z()/other.z() };
}

Vec3 Vec3::operator/(double t) const
{
    // ToDo: Elementwise divide this vector by the double t and return a new vector containing the value
    return Vec3{ x()/t, y()/t, z()/t };
}

double Vec3::LengthSquared() const
{
    // ToDo: Return the square of the length of this vector
    float length=0.0;
    length+=(x() * x());
    length+=(y() * y());
    length+=(z() * z());

    return length;
}

double Vec3::Length() const
{
    // ToDo: Return the length of this vector (Hint: Keep it bound ot LegthSquared() function)

    return sqrt(LengthSquared());
}

double Vec3::Dot(const Vec3& v1, const Vec3& v2)
{
    // ToDo: Return the DOT product between v1 and v2

    return v1.x()*v2.x() + v1.y()*v2.y() + v1.z()*v2.z();
}

double Vec3::Dot(const Vec3& other) const
{
    // ToDo: Return the DOT product between this and other vectors (Hint: Keep it bound to static Dot between v1 and v2)
    return Dot( *this, other);
}

Vec3 Vec3::Cross(const Vec3& v1, const Vec3& v2)
{
    // ToDo: Return the CROSS product between v1 and v2 as a new Vec3
    return Vec3{ v1.y()*v2.z() - v1.z()*v2.y(), v1.z()*v2.x() - v1.x()*v2.z(), v1.x()*v2.y() - v1.y()*v2.z(),  };
}

Vec3 Vec3::Cross(const Vec3& other) const
{
    // ToDo: Return the CROSS product between this and other vectors (Hint: Keep it bound to static Cross between v1 and v2)
    return Cross(*this, other);
}

bool Vec3::NearZero() const
{
    // ToDo: Return whether all 3 members of this vector is near zero (Abs is lower than K_EPSILON from Util.h)
    // It is necessary later on since floating point calculations are not accurate

    bool ans=1;
    if(x()<K_EPSILON || y()<K_EPSILON || z()<K_EPSILON ) ans=0;

    return ans;
}

Vec3 Vec3::Random()
{
    // ToDo: Return a Vec3 having random X, Y and Z values between [0.0, 1.0) (Hint: Check Util.h)

    return Vec3{ RandomDouble(0.0, 1.0),RandomDouble(0.0, 1.0), RandomDouble(0.0, 1.0) }; // Implicit conversion to Vec3{1000.0}
}

Vec3 Vec3::Random(double min, double max)
{
    // ToDo: Return a Vec3 having random X, Y and Z values between [min, max) (Hint: Check Util.h)
    return 1000.0; // Implicit conversion to Vec3{1000.0}
}

Vec3 operator+(double t, const Vec3& v)
{
    // ToDo: Overload + operator so that double + Vec3 can be performed (Hint: Just return Vec3 + double to flip ordering)
    return Vec3{};
}

Vec3 operator-(double t, const Vec3& v)
{
    // ToDo: Overload - operator so that double - Vec3 can be performed (Hint: Like the previous one)
    return Vec3{};
}

Vec3 operator*(double t, const Vec3& v)
{
    // ToDo: Overload * operator so that double * Vec3 can be performed (Hint: Like the previous one)
    return Vec3{};
}

Vec3 operator/(double t, const Vec3& v)
{
    // ToDo: Overload / operator so that double / Vec3 can be performed (Hint: Like the previous one)
    return Vec3{};
}

Vec3 UnitVector(const Vec3& v)
{
    // ToDo: Return a unit vector in the direction of v
    return Vec3{};
}

double Angle(const Vec3& vec1, const Vec3& vec2)
{
    // ToDo: Return the angle between vec1 and vec2 in radians
    return 0.0;
}

//20.0 = double
//20.0 = float

//rvalue= variable pointer
//lvalue= value