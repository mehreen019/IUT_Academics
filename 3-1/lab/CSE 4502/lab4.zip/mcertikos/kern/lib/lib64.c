// lib64.c - Implementation of 64-bit division functions

// Division of 64-bit unsigned integers
unsigned long long __udivdi3(unsigned long long a, unsigned long long b) {
    // Simple implementation using a loop
    unsigned long long quotient = 0;
    unsigned long long remainder = 0;
    
    // Process 64 bits
    for (int i = 63; i >= 0; i--) {
        // Shift remainder left by 1 bit and add the next bit from a
        remainder = (remainder << 1) | ((a >> i) & 1);
        
        // If remainder is greater than or equal to b, subtract b and set quotient bit
        if (remainder >= b) {
            remainder -= b;
            quotient |= (1ULL << i);
        }
    }
    
    return quotient;
}

// Modulo of 64-bit unsigned integers
unsigned long long __umoddi3(unsigned long long a, unsigned long long b) {
    // We can use the division function and then calculate the remainder
    unsigned long long quotient = __udivdi3(a, b);
    return a - (quotient * b);
}
