#ifndef _KERN_LIB_ELF_H_
#define _KERN_LIB_ELF_H_

#ifdef _KERN_

#include <lib/types.h>

#define ELF_MAGIC 0x464C457FU  /* "\x7FELF" in little endian */

// ELF header
typedef struct elfhdf {
    uint32_t e_magic;  // must equal ELF_MAGIC
    uint8_t e_elf[12];
    uint16_t e_type;
    uint16_t e_machine;
    uint32_t e_version;
    uint32_t e_entry;
    uint32_t e_phoff;
    uint32_t e_shoff;
    uint32_t e_flags;
    uint16_t e_ehsize;
    uint16_t e_phentsize;
    uint16_t e_phnum;
    uint16_t e_shentsize;
    uint16_t e_shnum;
    uint16_t e_shstrndx;
} elfhdr;

// ELF program header
typedef struct proghdr {
    uint32_t p_type;
    uint32_t p_offset;
    uint32_t p_va;
    uint32_t p_pa;
    uint32_t p_filesz;
    uint32_t p_memsz;
    uint32_t p_flags;
    uint32_t p_align;
} proghdr;

// ELF section header
typedef struct sechdr {
    uint32_t sh_name;
    uint32_t sh_type;
    uint32_t sh_flags;
    uint32_t sh_addr;
    uint32_t sh_offset;
    uint32_t sh_size;
    uint32_t sh_link;
    uint32_t sh_info;
    uint32_t sh_addralign;
    uint32_t sh_entsize;
} sechdr;

// Values for proghdr::p_type
#define ELF_PROG_LOAD 1

// Flag bits for proghdr::p_flags
#define ELF_PROG_FLAG_EXEC  1
#define ELF_PROG_FLAG_WRITE 2
#define ELF_PROG_FLAG_READ  4

// Values for sechdr::sh_type
#define ELF_SHT_NULL     0
#define ELF_SHT_PROGBITS 1
#define ELF_SHT_SYMTAB   2
#define ELF_SHT_STRTAB   3

// Values for sechdr::sh_name
#define ELF_SHN_UNDEF 0

void elf_load(void *exe_ptr, int pid);
uintptr_t elf_entry(void *exe_ptr);

#endif  /* _KERN_ */

#endif  /* !_KERN_LIB_ELF_H_ */
