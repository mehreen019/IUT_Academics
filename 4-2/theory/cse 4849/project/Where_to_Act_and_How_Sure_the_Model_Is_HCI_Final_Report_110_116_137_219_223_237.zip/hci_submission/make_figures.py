"""Build the two data figures of the HCI final report.

Inputs (all real, no simulated values):
  data/walkthrough_p1.csv          per-trial log of the single-evaluator walkthrough
                                   (transcribed from results/metrics/walkthrough_log.csv;
                                   replace with the original CSV if columns differ)
  data/companion_canonical_summary.json   class-level IoU, pretrained checkpoint, canonical words
  figures/raw_companion/*.png      before/after renderings from the companion report
                                   (held-out *question* queries, NOT the queries used in the walkthrough)

Outputs:
  figures/fig_trials.pdf   per-trial IoU coloured by interface state
  figures/fig_maps.pdf     ground-truth vs fine-tuned score maps for the six walkthrough shapes
"""
import json
import glob
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from PIL import Image

plt.rcParams.update({
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "font.family": "DejaVu Sans", "font.size": 7,
    "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
})

BLUE, ORANGE, GREY = "#0072B2", "#E69F00", "#6b6b6b"

log = pd.read_csv("data/walkthrough_p1.csv")
canon = json.load(open("data/companion_canonical_summary.json"))["per_class_iou"]
ref = {"sittable": canon["sittable"], "cut": canon["cut"], "pourable": canon["pourable"],
       "grasp": canon["grasp"], "contain": canon["contain"]}

# ---------------------------------------------------------------- Figure 1: per-trial IoU
fig, ax = plt.subplots(figsize=(3.45, 2.55))
x = np.arange(len(log))
for i, r in log.iterrows():
    if pd.isna(r.miou):
        # unsupported query: nothing to score, but the interface still showed a normal result
        ax.bar(i, 0.05, width=0.62, fill=False, edgecolor=BLUE, linestyle="--", linewidth=0.9)
        ax.text(i, 0.075, "no IoU\n(no target\naffordance)", ha="center", va="bottom",
                fontsize=5.6, color=GREY)
        continue
    color = ORANGE if r.state == "low_confidence" else BLUE
    hatch = "///" if r.state == "low_confidence" else None
    ax.bar(i, max(r.miou, 0.004), width=0.62, color=color, edgecolor="black" if hatch else color,
           hatch=hatch, linewidth=0.4)
    ax.text(i, r.miou + 0.02, f"{r.miou:.3f}", ha="center", va="bottom", fontsize=6.3)
    if r.affordance in ref:
        ax.plot([i - 0.36, i + 0.36], [ref[r.affordance]] * 2, color="black", lw=1.1, zorder=5)

# tier separators
for xb in (1.5, 4.5):
    ax.axvline(xb, color=GREY, lw=0.5, ls=":")
for xc, name in ((0.5, "Easy"), (3.0, "Moderate"), (5.5, "Hard")):
    ax.text(xc, 0.98, name, ha="center", va="top", fontsize=6.8, fontweight="bold")

ax.set_xticks(x)
ax.set_xticklabels([f"T{int(t)}\n{o}" for t, o in zip(log.trial, log.object)], fontsize=6.4)
ax.set_ylim(0, 1.0)
ax.set_xlim(-0.6, len(log) - 0.4)
ax.set_ylabel("Per-trial IoU with ground truth")
ax.spines[["top", "right"]].set_visible(False)
ax.legend(handles=[
    Patch(facecolor=BLUE, label="normal result shown\n(dashed outline: not scoreable)"),
    Patch(facecolor=ORANGE, edgecolor="black", hatch="///", linewidth=0.4, label="low-confidence flag shown"),
    Line2D([0], [0], color="black", lw=1.1, label="class-level IoU (pretrained,\ncanonical words; reference only)"),
], loc="upper right", bbox_to_anchor=(1.0, 0.90), fontsize=5.6, frameon=False, handlelength=1.4,
    borderaxespad=0.1, labelspacing=0.35)
fig.tight_layout(pad=0.4)
fig.savefig("figures/fig_trials.pdf")
plt.close(fig)

# ---------------------------------------------------------------- Figure 2: companion score maps
def crop_panels(path):
    im = np.array(Image.open(path).convert("RGB"))
    nonwhite = im.min(axis=2) < 235
    band = nonwhite[150:480, :]
    cols = band.any(axis=0)
    W = im.shape[1]
    groups, start, last = [], None, None
    for xx in range(W):
        if cols[xx]:
            start = xx if start is None else start
            last = xx
        elif start is not None and xx - last > 30:
            groups.append((start, last)); start = None
    if start is not None:
        groups.append((start, last))
    gt, _, ft, _ = groups          # ground truth, pretrained, fine-tuned, colourbar
    out = []
    for (a, b) in (gt, ft):
        sub = nonwhite[150:480, a:b + 1]
        rows = np.where(sub.any(axis=1))[0]
        r0, r1 = rows.min() + 150, rows.max() + 150
        out.append(im[max(r0 - 6, 0):r1 + 6, max(a - 6, 0):b + 7])
    return out

cells = [  # (raw file prefix, label, trial tag)
    ("chair_sittable", "Chair, sittable", "T1"),
    ("knife_cut", "Knife, cut", "T2"),
    ("mug_pourable", "Mug, pourable", "T3"),
    ("bag_grasp", "Bag, grasp", "T4, T5"),
    ("bowl_contain", "Bowl, contain", "T6"),
    ("bottle_grasp", "Bottle, grasp", "T7*"),
]
fig = plt.figure(figsize=(7.1, 3.35))
outer = fig.add_gridspec(2, 3, left=0.005, right=0.93, top=0.94, bottom=0.03, wspace=0.10, hspace=0.34)
for k, (prefix, label, tag) in enumerate(cells):
    f = glob.glob(f"figures/raw_companion/{prefix}_*.png")[0]
    gt, ft = crop_panels(f)
    inner = outer[k // 3, k % 3].subgridspec(1, 2, wspace=0.02)
    for j, (img, name) in enumerate(((gt, "ground truth"), (ft, "fine-tuned"))):
        a = fig.add_subplot(inner[0, j])
        a.imshow(img); a.set_xticks([]); a.set_yticks([])
        for s in a.spines.values():
            s.set_visible(False)
        a.set_xlabel(name, fontsize=6.3, labelpad=1.5)
        if j == 0:
            a.set_title(f"{tag}: {label}", fontsize=7.2, fontweight="bold", loc="left", pad=3)
cax = fig.add_axes([0.955, 0.16, 0.012, 0.66])
sm = plt.cm.ScalarMappable(cmap="viridis", norm=plt.Normalize(0, 1))
cb = fig.colorbar(sm, cax=cax)
cb.set_label("affordance score\n(ground truth: 0 or 1)", fontsize=6.2)
cb.ax.tick_params(labelsize=6)
fig.savefig("figures/fig_maps.pdf")
plt.close(fig)
print("wrote figures/fig_trials.pdf and figures/fig_maps.pdf")
